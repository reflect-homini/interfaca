// API Response Types based on API Contract

export interface ApiError {
  message: string;
  code: number;
}

export interface Pagination {
  totalData: number;
  currentPage: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPrevPage: boolean;
}

export interface ApiResponse<T> {
  data?: T;
  errors?: ApiError[];
  pagination?: Pagination;
}

// Auth Types
export interface TokenResponse {
  type: "Bearer";
  token: string;
  refreshToken: string;
}

export interface RegisterRequest {
  email: string;
  password: string;
  passwordConfirmation: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RefreshTokenRequest {
  refreshToken: string;
}

export interface PasswordResetRequest {
  email: string;
}

export interface ResetPasswordRequest {
  token: string;
  password: string;
  passwordConfirmation: string;
}

// User Types
export interface Profile {
  id: string;
  createdAt: string;
  updatedAt: string;
  userId: string;
  name: string;
  avatar: string;
}

export interface User {
  id: string;
  createdAt: string;
  updatedAt: string;
  email: string;
  profile: Profile;
}
