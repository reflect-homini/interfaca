import { tokenStorage } from "@/auth/tokenStorage";
import type { ApiResponse, TokenResponse } from "./types";

const BASE_URL = import.meta.env.VITE_API_BASE_URL || "/api/v1";

// Track refresh state to prevent multiple simultaneous refreshes
let isRefreshing = false;
let refreshPromise: Promise<TokenResponse | null> | null = null;

export class ApiError extends Error {
  constructor(
    public message: string,
    public code: number,
    public errors?: Array<{ message: string; code: number }>
  ) {
    super(message);
    this.name = "ApiError";
  }
}

async function refreshTokens(): Promise<TokenResponse | null> {
  const refreshToken = tokenStorage.getRefreshToken();
  if (!refreshToken) {
    return null;
  }

  try {
    const response = await fetch(`${BASE_URL}/auth/refresh`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ refreshToken }),
    });

    if (!response.ok) {
      tokenStorage.clearTokens();
      return null;
    }

    const result: ApiResponse<TokenResponse> = await response.json();
    if (result.data) {
      tokenStorage.setTokens(result.data.token, result.data.refreshToken);
      return result.data;
    }

    return null;
  } catch {
    tokenStorage.clearTokens();
    return null;
  }
}

async function handleTokenRefresh(): Promise<TokenResponse | null> {
  if (isRefreshing && refreshPromise) {
    return refreshPromise;
  }

  isRefreshing = true;
  refreshPromise = refreshTokens().finally(() => {
    isRefreshing = false;
    refreshPromise = null;
  });

  return refreshPromise;
}

interface RequestOptions extends Omit<RequestInit, "body"> {
  body?: unknown;
  skipAuth?: boolean;
}

export async function apiRequest<T>(
  endpoint: string,
  options: RequestOptions = {}
): Promise<T> {
  const { body, skipAuth = false, ...fetchOptions } = options;

  const headers: HeadersInit = {
    "Content-Type": "application/json",
    ...fetchOptions.headers,
  };

  if (!skipAuth) {
    const accessToken = tokenStorage.getAccessToken();
    if (accessToken) {
      (headers as Record<string, string>)["Authorization"] = `Bearer ${accessToken}`;
    }
  }

  const config: RequestInit = {
    ...fetchOptions,
    headers,
  };

  if (body !== undefined) {
    config.body = JSON.stringify(body);
  }

  let response = await fetch(`${BASE_URL}${endpoint}`, config);

  // Handle 401 - try to refresh tokens
  if (response.status === 401 && !skipAuth) {
    const newTokens = await handleTokenRefresh();
    if (newTokens) {
      // Retry the original request with new token
      (headers as Record<string, string>)["Authorization"] = `Bearer ${newTokens.token}`;
      response = await fetch(`${BASE_URL}${endpoint}`, {
        ...config,
        headers,
      });
    } else {
      // Refresh failed, redirect to login
      tokenStorage.clearTokens();
      window.location.href = "/login";
      throw new ApiError("Session expired. Please log in again.", 401);
    }
  }

  // Handle 204 No Content
  if (response.status === 204) {
    return undefined as T;
  }

  const result: ApiResponse<T> = await response.json();

  // Handle API errors
  if (result.errors && result.errors.length > 0) {
    throw new ApiError(
      result.errors[0].message,
      result.errors[0].code,
      result.errors
    );
  }

  if (!response.ok) {
    throw new ApiError("An unexpected error occurred", response.status);
  }

  return result.data as T;
}

// Auth API functions
export const authApi = {
  login: (email: string, password: string) =>
    apiRequest<TokenResponse>("/auth/login", {
      method: "POST",
      body: { email, password },
      skipAuth: true,
    }),

  register: (email: string, password: string, passwordConfirmation: string) =>
    apiRequest<{ message: string }>("/auth/register", {
      method: "POST",
      body: { email, password, passwordConfirmation },
      skipAuth: true,
    }),

  verifyRegistration: (token: string) =>
    apiRequest<void>(`/auth/verify-registration?token=${encodeURIComponent(token)}`, {
      method: "GET",
      skipAuth: true,
    }),

  sendPasswordReset: (email: string) =>
    apiRequest<void>("/auth/password-reset", {
      method: "POST",
      body: { email },
      skipAuth: true,
    }),

  resetPassword: (token: string, password: string, passwordConfirmation: string) =>
    apiRequest<void>("/auth/reset-password", {
      method: "PATCH",
      body: { token, password, passwordConfirmation },
      skipAuth: true,
    }),

  logout: () =>
    apiRequest<void>("/auth/logout", {
      method: "DELETE",
    }),

  getOAuthUrl: (provider: string) =>
    `${BASE_URL}/auth/${provider}`,

  oauthCallback: (provider: string, code: string, state: string) =>
    apiRequest<TokenResponse>(`/auth/${provider}/callback?code=${encodeURIComponent(code)}&state=${encodeURIComponent(state)}`, {
      method: "GET",
      skipAuth: true,
    }),
};

// User API functions
export const userApi = {
  getMe: () => apiRequest<import("./types").User>("/me"),
};
