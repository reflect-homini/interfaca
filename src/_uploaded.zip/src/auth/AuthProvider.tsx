import {
  createContext,
  useContext,
  useCallback,
  useMemo,
  type ReactNode,
} from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { authApi, userApi, ApiError } from "@/api/client";
import { tokenStorage } from "./tokenStorage";
import type { User, TokenResponse } from "@/api/types";
import { toast } from "sonner";

interface AuthContextValue {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  handleOAuthCallback: (
    provider: string,
    code: string,
    state: string
  ) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();

  // Fetch current user
  const {
    data: user,
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["user", "me"],
    queryFn: userApi.getMe,
    enabled: tokenStorage.hasTokens(),
    retry: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: ({ email, password }: { email: string; password: string }) =>
      authApi.login(email, password),
    onSuccess: (data: TokenResponse) => {
      tokenStorage.setTokens(data.token, data.refreshToken);
      queryClient.invalidateQueries({ queryKey: ["user", "me"] });
    },
    onError: (error: unknown) => {
      if (error instanceof ApiError) {
        toast.error(error.message);
      } else {
        console.error("Unexpected login error:", error);
        toast.error("Unexpected error occurred");
      }
    },
  });

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: authApi.logout,
    onSuccess: () => {
      tokenStorage.clearTokens();
      queryClient.clear();
    },
    onError: () => {
      // Even if API call fails, clear local state
      tokenStorage.clearTokens();
      queryClient.clear();
    },
  });

  const login = useCallback(
    async (email: string, password: string) => {
      await loginMutation.mutateAsync({ email, password });
    },
    [loginMutation]
  );

  const logout = useCallback(async () => {
    await logoutMutation.mutateAsync();
  }, [logoutMutation]);

  const handleOAuthCallback = useCallback(
    async (provider: string, code: string, state: string) => {
      try {
        const data = await authApi.oauthCallback(provider, code, state);
        tokenStorage.setTokens(data.token, data.refreshToken);
        queryClient.invalidateQueries({ queryKey: ["user", "me"] });
      } catch (error) {
        if (error instanceof ApiError) {
          toast.error(error.message);
        } else {
          console.error("OAuth callback error:", error);
          toast.error("Unexpected error occurred");
        }
        throw error;
      }
    },
    [queryClient]
  );

  const value = useMemo(
    () => ({
      user: user ?? null,
      isAuthenticated: !!user && !isError,
      isLoading,
      login,
      logout,
      handleOAuthCallback,
    }),
    [user, isError, isLoading, login, logout, handleOAuthCallback]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
